'''
Sail solution

Author: Pham Thanh Tuyen
Project: https://github.com/phamtyn/sail/
'''

import tensorflow as tf
from input_data import *
import sys
import os
import itertools
import re
import time
import json
from random import randint

TEST_RATIO = 0.1
BATCH_POWER = 0.46
NUM_OUTPUT_CLASSES = 5
NUM_LAYER1_NODES = 32
ONE_HOT = True
learning_rate = 0.005
training_iters = 100000
dropout = 0.75

data_file = ""

tb_directory = os.environ["LOG_DIR"]+"/"+os.environ["SUBID"]+"/logs/tb"

model_path = os.environ["RESULT_DIR"]+"/model"

test_metrics = []

try:
    with open("config.json", 'r') as f:
        json_obj = json.load(f)

    learning_rate = json_obj["learning_rate"]
    NUM_LAYER1_NODES = json_obj["NUM_LAYER1_NODES"]
    training_iters = json_obj["training_iters"]
    dropout = json_obj["dropout"]
except:
    pass

# This helps distinguish instances when the training job is restarted.
instance_id = randint(0,9999)

def main(argv):

    if len(argv) < 3 or str(argv[1]) != "--dataFile":
        sys.exit("Invalid arguments.")
        
    global data_file
    data_file = str(argv[2])

if __name__ == "__main__":
    main(sys.argv)


rawdata, COLUMN_TITLES = retrieve_file_data(data_file)
NUM_INPUT = len(rawdata[0].split(',')) - 1
NUM_SAMPLES_TEST = int(TEST_RATIO * len(rawdata))
NUM_SAMPLES_TRAIN = len(rawdata) - NUM_SAMPLES_TEST
batch_size = (int)(max(pow(NUM_SAMPLES_TRAIN, BATCH_POWER), np.log2(NUM_SAMPLES_TRAIN)))

train_data, train_labels = getdata(rawdata)
MAX_INPUT_VALUES, MIN_INPUT_VALUES = calmaxmin(train_data, NUM_INPUT)

train_data = refine_data(train_data, NUM_INPUT, MAX_INPUT_VALUES, MIN_INPUT_VALUES)
train_labels = string2float(train_labels)
if ONE_HOT:
    train_labels = dense_to_one_hot(train_labels, NUM_OUTPUT_CLASSES)

perm = np.arange(len(train_data))
np.random.shuffle(perm)
train_data = train_data[perm]
train_labels = train_labels[perm]

test_data = train_data[:NUM_SAMPLES_TEST]    
test_labels = train_labels[:NUM_SAMPLES_TEST]

train_data = train_data[NUM_SAMPLES_TEST:]
train_labels = train_labels[NUM_SAMPLES_TEST:]

train = DataSet(train_data, train_labels)


x = tf.placeholder( tf.float32, shape = ( None, NUM_INPUT ), name="x_input")
y = tf.placeholder( tf.float32, shape = ( None, NUM_OUTPUT_CLASSES ) )
# Layer 1
w1 = tf.Variable( tf.truncated_normal( shape=[ NUM_INPUT, NUM_LAYER1_NODES ] ) )
b1 = tf.Variable( tf.zeros( shape=[ NUM_LAYER1_NODES ] ) )
layer1_output =  tf.nn.relu( tf.matmul( x, w1 ) +  b1 )
#dropout
layer1_output = tf.nn.dropout(layer1_output, dropout)
# In future TensorFlow versions, rate flag is recommended instead of
# keep_prob flag.
# fc1 = tf.nn.dropout(fc1, rate=(1 - dropout))
# Output
w2 = tf.Variable( tf.truncated_normal( shape=[ NUM_LAYER1_NODES, NUM_OUTPUT_CLASSES ] ) )
b2 = tf.Variable( tf.zeros( shape=[ NUM_OUTPUT_CLASSES ] ) )
output = tf.nn.softmax( tf.matmul( layer1_output, w2 ) + b2 )

# Train the model
cost = tf.losses.softmax_cross_entropy( y, output )
optimizer = tf.train.AdamOptimizer( learning_rate ).minimize( cost )
display_step = 100

predictor = tf.argmax(output, 1, name="predictor")

# Evaluate model
correct_pred = tf.equal(tf.argmax(output, 1), tf.argmax(y, 1))
accuracy = tf.reduce_mean(tf.cast(correct_pred, tf.float32))

tf.summary.scalar('accuracy', accuracy)

# Initializing the variables
init = tf.global_variables_initializer()

# Launch the graph
with tf.Session() as sess:
    sess.run(init)

    merged = tf.summary.merge_all()
    
    test_writer = tf.summary.FileWriter(tb_directory+'/test')
    step = 1
    # Keep training until reach max iterations

    while step * batch_size < training_iters:
        batch_x, batch_y = train.next_batch(batch_size)
        # Run optimization
        sess.run(optimizer, feed_dict={x: batch_x, y: batch_y})
        if step % display_step == 0:

            # Calculate batch loss and accuracy
            train_summary, train_acc = sess.run([merged, accuracy], feed_dict={x: batch_x, y: batch_y})
            test_summary, test_acc = sess.run([merged, accuracy], feed_dict={x: test_data, y: test_labels})

            test_writer.add_summary(test_summary, step*batch_size)
            print("Time " + "{:.4f}".format(time.time()) + \
                  ", instance " + str(instance_id) + \
                  ", Iter " + str(step * batch_size) + \
                  ", Training Accuracy= " + "{:.5f}".format(train_acc))

            test_metrics.append((step*batch_size, {"accuracy": float(test_acc)}))
            sys.stdout.flush()
        step += 1
    print("Optimization Finished!")

    classification_inputs = tf.saved_model.utils.build_tensor_info(x)
    classification_outputs_classes = tf.saved_model.utils.build_tensor_info(predictor)

    classification_signature = (
        tf.saved_model.signature_def_utils.build_signature_def(
            inputs={
                tf.saved_model.signature_constants.CLASSIFY_INPUTS:
                    classification_inputs
            },
            outputs={
                tf.saved_model.signature_constants.CLASSIFY_OUTPUT_CLASSES:
                    classification_outputs_classes
            },
            method_name=tf.saved_model.signature_constants.CLASSIFY_METHOD_NAME))

    print("classification_signature content:")
    print(classification_signature)

    # Calculate accuracy for 10% examples
    print("Testing Accuracy:", \
        sess.run(accuracy, feed_dict={x: test_data, y: test_labels}))

    builder = tf.saved_model.builder.SavedModelBuilder(model_path)
    legacy_init_op = tf.group(tf.tables_initializer(), name='legacy_init_op')
    builder.add_meta_graph_and_variables(
       sess, [tf.saved_model.tag_constants.SERVING],
       signature_def_map={
           'predict_images': classification_signature,
       },
       legacy_init_op=legacy_init_op)

    save_path = str(builder.save())


training_out =[]

for test_metric in test_metrics:
    out = {'steps':test_metric[0]}
    for (metric,value) in test_metric[1].items():
        out[metric] = value
    training_out.append(out)

with open('{}/val_dict_list.json'.format(os.environ['RESULT_DIR']), 'w') as f:
    json.dump(training_out, f)
