import numpy as np
import gzip

def retrieve_file_data(filename):
    with gzip.open(filename, "rt") as f:
        s = f.read()
        s = s.split('\n')
        s.pop()
        column_titles = s.pop(0)
        return s, column_titles

def getdata(rawdata):
    data = []
    labels = []
    for line in rawdata:
        arr = line.split(',')
        labels += [ arr.pop() ]
        data += arr
    return data, labels

dict_data = {
    'US': 0,
    'Japan': 1,
    'Panama': 2,
    'Vietnam': 3,
    'General Cargo': 0,
    'Bulk Carriers': 1,
    'Container': 2,
    'Ro-Ro': 3,
    'Oil Tanker': 4,
    'Liquefied Gas': 5,
    'Chemical Carriers': 6,
    'American': 0,
    'Japanese': 1,
    'Korean': 2,
    'Chinese': 3,
    'Philippines': 4,
    'Vietnamese': 5,
    'Multi-national': 6,
    'Rice in bags': 0,
    'Soybean milk': 1,
    'Tapioca chip': 2,
    'Grain in bulk': 3,
    'Coal': 4,
    'Cement': 5,
    'Clay': 6,
    'Ore in bulk': 7,
    'Ore in jumbo bag': 8,
    'Timber': 9,
    'Logs': 10,
    'Cars': 11,
    'Equipment': 12,
    'Steel products': 13,
    'Heavy-lift': 14,
    'Containers': 15,
    'Product oil': 16,
    'Crude oil': 17,
    'Chemical': 18,
    'Gas': 19,
    'Pacific': 0,
    'Indian Ocean': 1,
    'Atlantic': 2,
    'Indonesia Sea': 3,
    'Yellow Sea': 4,
    'Mediterranean': 5,
    'Summer': 0,
    'Winter': 1,
    'Good': 0,
    'Normal': 1,
    'Bad': 2,
    'Danger': 3,
    'Safe': 0,
    'Low Risk': 1,
    'Medium Risk': 2,
    'High Risk': 3,
    'Dangerous': 4,
}

dict_result = {
    0: 'Safe',
    1: 'Low Risk',
    2: 'Medium Risk',
    3: 'High Risk',
    4: 'Dangerous',
}

def string2float(words):
    li = []
    for k in words:
        try:
            num = float(k)
            li.append(num)
        except ValueError:
            li.append(dict_data.get(k, 0))
    return np.array(li)

def int2string(ints):
    results = []
    for k in ints:
        results.append(dict_result[k])
    return results

def calmaxmin(input_array, num_input):
    columns = (string2float(input_array).reshape(-1, num_input)).T
    return [ max(col) for col in columns ], [ min(col) for col in columns ]

def rate(a, max_arg, min_arg):
    max_np = np.array(max_arg)
    return (a - min_arg) / (max_np - min_arg)

def refine_data(input_data, num_input, max_input_values, min_input_values):
    data = string2float(input_data).reshape(-1, num_input)
    data = rate(data, max_input_values, min_input_values)
    return data

def dense_to_one_hot(labels_dense, num_classes):
    '''Convert class labels from scalars to one-hot vectors.'''
    num_labels = labels_dense.shape[0]
    index_offset = np.arange(num_labels) * num_classes
    labels_one_hot = np.zeros((num_labels, num_classes))
    labels_one_hot.flat[index_offset + labels_dense.ravel()] = 1
    return labels_one_hot

class DataSet(object):
    def __init__(self, data, labels):
        self._data = data
        self._labels = labels
        self._num_examples = len(data)
        self._index_in_epoch = 0

    def next_batch(self, batch_size):

        start = self._index_in_epoch
        self._index_in_epoch += batch_size

        if self._index_in_epoch > self._num_examples:
            # Shuffle the data
            perm = np.arange(self._num_examples)
            np.random.shuffle(perm)
            self._data = self._data[perm]
            self._labels = self._labels[perm]
            # Start next epoch
            start = 0
            self._index_in_epoch = batch_size

        end = self._index_in_epoch

        return self._data[start:end], self._labels[start:end]
